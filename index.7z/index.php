<!doctype html>
<html xml:lang="es-es" lang="es-es" >

<!-- Mirrored from www.inoqua.com.uy/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 14 Jun 2018 01:07:23 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
  	<meta name="google-site-verification" content="GE0CLxNrwqsRpfR5qHmm7hI74B5TUifNKp06bqc2WUA" />
		<meta name="viewport" content="width=1200px">
			
    <base  />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="-	InoQuafue creada para satisfacer las necesidades de la industria y establecimientos que requieran acompañamiento para cumplir con las normas vigentes en  producción, transporte, almacenamiento y comercialización de alimentos." />
	<meta name="rights" content="-	InoQuafue creada para satisfacer las necesidades de la industria y establecimientos que requieran acompañamiento para cumplir con las normas vigentes en  producción, transporte, almacenamiento y comercialización de alimentos." />
	<meta name="description" content="-	InoQuafue creada para satisfacer las necesidades de la industria y establecimientos que requieran acompañamiento para cumplir con las normas vigentes en  producción, transporte, almacenamiento y comercialización de alimentos." />
	<meta name="generator" content="Joomla! - Open Source Content Management" />
	<title>INOQUA - Quienes Somos</title>
	<link href="indexc0d0.html?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
	<link href="index7b17.html?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
	<link href="css/rokbox.css" rel="stylesheet" type="text/css" />
	<link href="css/menu-866aa62ff6c16fcab414a76f625ee345.css" rel="stylesheet" type="text/css" />
	<link href="css/grid-responsive.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="css/master-1af8fbbfdaf38550e6074137e645adfa.css" rel="stylesheet" type="text/css" />
	<link href="css/1200fixed.css" rel="stylesheet" type="text/css" />
	<link href="http://fonts.googleapis.com/css?family=Lato:100,100italic,300,300italic,regular,italic,700,700italic,900,900italic" rel="stylesheet" type="text/css" />
	<link href="css/cards.css" rel="stylesheet" type="text/css" />
	<link href="css/slideshow.css" rel="stylesheet" type="text/css" />
	<style type="text/css">
#rt-logo {background: url(http://www.inoqua.com.uy/images/LOGO-PEQUEO.png) 50% 0 no-repeat !important;}
#rt-logo {width: 372px;height: 100px;}
#rt-feature{ position:relative; background-image:url(http://www.inoqua.com.uy/images/fondi.jpg); background-repeat:no-repeat; background-size: cover }#rt-feature:before { content: ''; background-color: #169ccc; position: absolute; top: 0; right: 0; bottom: 0; left: 0; opacity: 0.9; }
body, h1, h2, .gf-menu.l1, .jmslideshow .slideshow-content { font-family: 'Lato', 'Helvetica', arial, serif; }
	</style>
	<script type="application/json" class="joomla-script-options new">{"csrf.token":"42bcaf082ce4558fb0dad42def42d31b","system.paths":{"root":"","base":""}}</script>
	<script src="js/jquery.min.js?3bca43c70489df4c5cbfff289047cf74" type="text/javascript"></script>
	<script src="js/jquery-noconflict.js?3bca43c70489df4c5cbfff289047cf74" type="text/javascript"></script>
	<script src="js/jquery-migrate.min.js?3bca43c70489df4c5cbfff289047cf74" type="text/javascript"></script>
	<script src="js/caption.js?3bca43c70489df4c5cbfff289047cf74" type="text/javascript"></script>
	<script src="js/mootools-core.js?3bca43c70489df4c5cbfff289047cf74" type="text/javascript"></script>
	<script src="js/core.js?3bca43c70489df4c5cbfff289047cf74" type="text/javascript"></script>
	<script src="js/mootools-more.js?3bca43c70489df4c5cbfff289047cf74" type="text/javascript"></script>
	<script src="js/rokbox.js" type="text/javascript"></script>
	<script src="js/browser-engines.js" type="text/javascript"></script>
	<script src="js/mootools-mobile.js" type="text/javascript"></script>
	<script src="js/rokmediaqueries.js" type="text/javascript"></script>
	<script src="js/roksprocket.js" type="text/javascript"></script>
	<script src="js/moofx.js" type="text/javascript"></script>
	<script src="js/roksprocket.request.js" type="text/javascript"></script>
	<script src="js/strips.js" type="text/javascript"></script>
	<script src="js/strips-speeds.js" type="text/javascript"></script>
	<script src="js/features.js" type="text/javascript"></script>
	<script src="js/slideshow.js" type="text/javascript"></script>
	<script type="text/javascript">
jQuery(window).on('load',  function() {
				new JCaption('img.caption');
			});
if (typeof RokBoxSettings == 'undefined') RokBoxSettings = {pc: '100'};


if (typeof RokSprocket == 'undefined') RokSprocket = {};
Object.merge(RokSprocket, {
	SiteURL: 'http://www.inoqua.com.uy/',
	CurrentURL: 'http://www.inoqua.com.uy/',
	AjaxURL: 'http://www.inoqua.com.uy/index.php?option=com_roksprocket&amp;task=ajax&amp;format=raw&amp;ItemId=101'
});

window.addEvent('domready', function(){
		RokSprocket.instances.strips = new RokSprocket.Strips();
});

window.addEvent('domready', function(){
	RokSprocket.instances.strips.attach(109, '{"animation":"fadeDelay","autoplay":"0","delay":"2"}');
});
window.addEvent('load', function(){
   var overridden = false;
   if (!overridden && window.G5 && window.G5.offcanvas){
       var mod = document.getElement('[data-strips="109"]');
       mod.addEvents({
           touchstart: function(){ window.G5.offcanvas.detach(); },
           touchend: function(){ window.G5.offcanvas.attach(); }
       });
       overridden = true;
   };
});

window.addEvent('domready', function(){
		RokSprocket.instances.slideshow = new RokSprocket.Slideshow();
});

window.addEvent('domready', function(){
	RokSprocket.instances.slideshow.attach(122, '{"animation":"crossfade","autoplay":"1","delay":"3"}');
});
window.addEvent('load', function(){
   var overridden = false;
   if (!overridden && window.G5 && window.G5.offcanvas){
       var mod = document.getElement('[data-slideshow="122"]');
       mod.addEvents({
           touchstart: function(){ window.G5.offcanvas.detach(); },
           touchend: function(){ window.G5.offcanvas.attach(); }
       });
       overridden = true;
   };
});

	</script>
</head>
<body  class="logo-type-custom headerstyle-dark posfeature-repetir-type-no-repeat posutility-repetir-type-no-repeat posmaintop-repetir-type-no-repeat posmainbottom-repetir-type-no-repeat posextension-repetir-type-no-repeat posbottom-repetir-type-no-repeat posfooter-repetir-type-no-repeat font-family-lato font-size-is-default menu-type-dropdownmenu layout-mode-1200fixed col12">
        <header id="rt-top-surround" class="absoluto">
						<div id="rt-header">
			<div class="rt-container">
				<div class="rt-grid-12 rt-alpha rt-omega">
            <div class="rt-block logo-block">
            <a href="index.html" id="rt-logo"></a>
        </div>
        
</div>
				<div class="clear"></div>
			</div>
		</div>
			</header>
				<div id="rt-showcase">
				<div class="sprocket-features layout-slideshow" data-slideshow="122">
	<ul class="sprocket-features-img-list">
		
<li class="sprocket-features-index-1">
	<div class="sprocket-features-img-container" data-slideshow-image>
									<img src="http://www.inoqua.com.uy/images/01.jpg" alt="" style="max-width: 100%; height: auto;" />
						</div>
	<div class="sprocket-features-content sprocket-none" data-slideshow-content>
					</div>
</li>

<li class="sprocket-features-index-2">
	<div class="sprocket-features-img-container" data-slideshow-image>
									<img src="http://www.inoqua.com.uy/images/02.jpg" alt="" style="max-width: 100%; height: auto;" />
						</div>
	<div class="sprocket-features-content sprocket-none" data-slideshow-content>
					</div>
</li>

<li class="sprocket-features-index-3">
	<div class="sprocket-features-img-container" data-slideshow-image>
									<img src="http://www.inoqua.com.uy/images/03.jpg" alt="" style="max-width: 100%; height: auto;" />
						</div>
	<div class="sprocket-features-content sprocket-none" data-slideshow-content>
					</div>
</li>
	</ul>
		<div class="sprocket-features-arrows">
		<span class="arrow next" data-slideshow-next><span>&rsaquo;</span></span>
		<span class="arrow prev" data-slideshow-previous><span>&lsaquo;</span></span>
	</div>
		<div class="sprocket-features-pagination">
		<ul>
						    	<li class="active" data-slideshow-pagination="1"><span>1</span></li>
						    	<li data-slideshow-pagination="2"><span>2</span></li>
						    	<li data-slideshow-pagination="3"><span>3</span></li>
				</ul>
	</div>
</div>
	
		<div class="clear"></div>
	</div>
		<div id="rt-transition">
		<div id="rt-mainbody-surround">
						<div id="rt-feature">
				<div class="rt-container">
					<div class="rt-grid-12 rt-alpha rt-omega">
    	<div class="rt-block menu-block">
		<div class="gf-menu-device-container responsive-type-panel"></div>
<ul class="gf-menu l1 " >
                    <li class="item101 active last" >

            <a class="item" href="index.html"  >

                                Quienes Somos                            </a>


                    </li>
                            <li class="item121" >

            <a class="item" href="formacion.html"  >

                                Formación                            </a>


                    </li>
                            <li class="item125" >

            <a class="item" href="empresas-alimentarias.html"  >

                                empresas alimentarias                            </a>


                    </li>
                            <li class="item161" >

            <a class="item" href="asesoramiento.html"  >

                                Asesoramiento                            </a>


                    </li>
                            <li class="item200" >

            <a class="item" href="registro.html"  >

                                REGISTRO                            </a>


                    </li>
                            <li class="item201" >

            <a class="item" href="capacitacion.html"  >

                                capacitacion                            </a>


                    </li>
                            <li class="item202" >

            <a class="item" href="extras.html"  >

                                Extras                            </a>


                    </li>
                            <li class="item119" >

            <a class="item" href="contacto.html"  >

                                Contacto                            </a>


                    </li>
            </ul>		<div class="clear"></div>
	</div>
	
</div>
					<div class="clear"></div>
				</div>
			</div>
									<div id="rt-utility">
				<div class="rt-container">
					<div class="rt-grid-12 rt-alpha rt-omega">
               <div class="rt-block ">
           	<div class="module-surround">
	           		                	<div class="module-content">
	                		

<div class="custom"  >
	<p style="text-align: center;"><img src="../i.imgur.com/aPHUxcK.jpg" alt="" /></p>
<p style="text-align: center;"> </p>

<iframe width="1150" height="647" src="https://www.youtube.com/embed/_rwnwhSW5pw?rel=0" frameborder="0" allowfullscreen></iframe></div>
	                	</div>
                	</div>
           </div>
	           <div class="rt-block ">
           	<div class="module-surround">
	           				<div class="module-title">
	                		<h2 class="title">Actividades</h2>
			</div>
	                		                	<div class="module-content">
	                		 <div class="sprocket-strips-c" data-strips="109">
	<div class="sprocket-strips-c-overlay"><div class="css-loader-wrapper"><div class="css-loader"></div></div></div>
	<div class="sprocket-strips-c-container cols-2" data-strips-items>
		<div class="sprocket-strips-c-block" data-strips-item>
	<!--Plain-->
		<!--Plain-->
	<div class="sprocket-strips-c-item" data-strips-content>
					<img src="http://www.inoqua.com.uy/images/1.jpg" class="sprocket-strips-c-image" alt="Extras" />
				<div class="sprocket-strips-c-content">
						<h4 class="sprocket-strips-c-title" data-strips-toggler>
				<a href="extras.html">					Extras				</a>			</h4>
						<div class="sprocket-strips-c-extended">
				<div class="sprocket-strips-c-extended-info">
															<a href="extras.html" class="sprocket-strips-c-readon">Leer más</a>
									</div>
			</div>
		</div>
	</div>
	<!--Plain-->
		<!--Plain-->
</div>
<div class="sprocket-strips-c-block" data-strips-item>
	<!--Plain-->
		<!--Plain-->
	<div class="sprocket-strips-c-item" data-strips-content>
					<img src="http://www.inoqua.com.uy/images/2.jpg" class="sprocket-strips-c-image" alt="Formación" />
				<div class="sprocket-strips-c-content">
						<h4 class="sprocket-strips-c-title" data-strips-toggler>
				<a href="formacion.html">					Formación				</a>			</h4>
						<div class="sprocket-strips-c-extended">
				<div class="sprocket-strips-c-extended-info">
															<a href="formacion.html" class="sprocket-strips-c-readon">Leer más</a>
									</div>
			</div>
		</div>
	</div>
	<!--Plain-->
		<!--Plain-->
</div>
<div class="sprocket-strips-c-block" data-strips-item>
	<!--Plain-->
		<!--Plain-->
	<div class="sprocket-strips-c-item" data-strips-content>
					<img src="http://www.inoqua.com.uy/images/3.jpg" class="sprocket-strips-c-image" alt="empresas alimentarias" />
				<div class="sprocket-strips-c-content">
						<h4 class="sprocket-strips-c-title" data-strips-toggler>
				<a href="empresas-alimentarias.html">					empresas alimentarias				</a>			</h4>
						<div class="sprocket-strips-c-extended">
				<div class="sprocket-strips-c-extended-info">
															<a href="empresas-alimentarias.html" class="sprocket-strips-c-readon">Leer más</a>
									</div>
			</div>
		</div>
	</div>
	<!--Plain-->
		<!--Plain-->
</div>
<div class="sprocket-strips-c-block" data-strips-item>
	<!--Plain-->
		<!--Plain-->
	<div class="sprocket-strips-c-item" data-strips-content>
					<img src="http://www.inoqua.com.uy/images/4.jpg" class="sprocket-strips-c-image" alt="Asesoramiento" />
				<div class="sprocket-strips-c-content">
						<h4 class="sprocket-strips-c-title" data-strips-toggler>
				<a href="asesoramiento.html">					Asesoramiento				</a>			</h4>
						<div class="sprocket-strips-c-extended">
				<div class="sprocket-strips-c-extended-info">
															<a href="asesoramiento.html" class="sprocket-strips-c-readon">Leer más</a>
									</div>
			</div>
		</div>
	</div>
	<!--Plain-->
		<!--Plain-->
</div>
<div class="sprocket-strips-c-block" data-strips-item>
	<!--Plain-->
		<!--Plain-->
	<div class="sprocket-strips-c-item" data-strips-content>
					<img src="http://www.inoqua.com.uy/images/5.jpg" class="sprocket-strips-c-image" alt="REGISTRO" />
				<div class="sprocket-strips-c-content">
						<h4 class="sprocket-strips-c-title" data-strips-toggler>
				<a href="registro.html">					REGISTRO				</a>			</h4>
						<div class="sprocket-strips-c-extended">
				<div class="sprocket-strips-c-extended-info">
															<a href="registro.html" class="sprocket-strips-c-readon">Leer más</a>
									</div>
			</div>
		</div>
	</div>
	<!--Plain-->
		<!--Plain-->
</div>
<div class="sprocket-strips-c-block" data-strips-item>
	<!--Plain-->
		<!--Plain-->
	<div class="sprocket-strips-c-item" data-strips-content>
					<img src="http://www.inoqua.com.uy/images/6.jpg" class="sprocket-strips-c-image" alt="Capacitación" />
				<div class="sprocket-strips-c-content">
						<h4 class="sprocket-strips-c-title" data-strips-toggler>
				<a href="capacitacion.html">					Capacitación				</a>			</h4>
						<div class="sprocket-strips-c-extended">
				<div class="sprocket-strips-c-extended-info">
															<a href="capacitacion.html" class="sprocket-strips-c-readon">Leer más</a>
									</div>
			</div>
		</div>
	</div>
	<!--Plain-->
		<!--Plain-->
</div>
	</div>
	<div class="sprocket-strips-c-nav">
		<div class="sprocket-strips-c-pagination-hidden">
			<ul>
									    	<li class="active" data-strips-page="1"><span>1</span></li>
						</ul>
		</div>
			</div>
</div>
	                	</div>
                	</div>
           </div>
	
</div>
					<div class="clear"></div>
				</div>
			</div>
																		<div class="rt-container">
		    		          
<div id="rt-main" class="mb12">
                <div class="rt-container">
                    <div class="rt-grid-12 ">
                                                                                            </div>
                                        <div class="clear"></div>
                </div>
            </div>
		    	</div>
											</div>
	</div>
			<footer id="rt-footer-surround">
		
		<div id="rt-footer">
						<div class="rt-container footerdentro">
				<div class="rt-grid-4 rt-alpha">
               <div class="rt-block ">
           	<div class="module-surround">
	           				<div class="module-title">
	                		<h2 class="title">Sobre nosotros</h2>
			</div>
	                		                	<div class="module-content">
	                		

<div class="custom"  >
	<ul>
<li>&nbsp;InoQua fue creada para satisfacer las necesidades de la industria y establecimientos que requieran acompa&ntilde;amiento para cumplir con las normas vigentes en &nbsp;producci&oacute;n, transporte, almacenamiento y comercializaci&oacute;n de alimentos.</li>
</ul></div>
	                	</div>
                	</div>
           </div>
	
</div>
<div class="rt-grid-4">
               <div class="rt-block ">
           	<div class="module-surround">
	           				<div class="module-title">
	                		<h2 class="title">Contacto  </h2>
			</div>
	                		                	<div class="module-content">
	                		

<div class="custom"  >
	<p><span class="icon-home"></span><span style="vertical-align: inherit;"><span style="vertical-align: inherit;">Montevideo - Uruguay </span></span><br /> <span class="icon-phone"> </span><span style="vertical-align: inherit;"><span style="vertical-align: inherit;">Tel&eacute;fono: 099 123 558 o 099 052 788 </span></span><br /> <span class="icon-envelope"> </span><span style="vertical-align: inherit;"><span style="vertical-align: inherit;">Correo electr&oacute;nico:&nbsp;<a href="mailto:inoquaalimentos@gmail.com" target="_blank" rel="noopener noreferrer">inoquaalimentos@gmail.com</a> </span></span><br /> <span class="icon-globe"> </span><span style="vertical-align: inherit;"><span style="vertical-align: inherit;">Web: www.inoqua.com.uy</span></span></p></div>
	                	</div>
                	</div>
           </div>
	
</div>
<div class="rt-grid-4 rt-omega">
               <div class="rt-block ">
           	<div class="module-surround">
	           				<div class="module-title">
	                		<h2 class="title">Conéctate</h2>
			</div>
	                		                	<div class="module-content">
	                		

<div class="custom"  >
	<p><img src="http://www.inoqua.com.uy/images/icon_facebook.png" alt="facebook" style="margin: 0 5px 0 0;" /> <img src="http://www.inoqua.com.uy/images/icon_twitter.png" alt="twitter" style="margin: 0 5px 0 0;" /> <img src="http://www.inoqua.com.uy/images/icon_google.png" alt="google" style="margin: 0 5px 0 0;" /> <img src="http://www.inoqua.com.uy/images/icon_youtube.png" alt="youtube" style="margin: 0 5px 0 0;" /></p>
<p>&nbsp;<a title="Contador De Visitas Gratis"><img src="http://www.websmultimedia.com/contador-de-visitas.php?id=238712" alt="contador de visitas" style="border: 0px solid; display: inline;" /></a></p>
<center><a href="http://www.websmultimedia.com/contador-de-visitas-gratis"></a></center></div>
	                	</div>
                	</div>
           </div>
	
</div>
				<div class="clear"></div>
			</div>
			
					</div>
	</footer>
				</body>

<!-- Mirrored from www.inoqua.com.uy/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 14 Jun 2018 01:07:29 GMT -->
</html>
